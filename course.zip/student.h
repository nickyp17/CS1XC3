/**
 * @file student.h
 * @author Nicholas Poulidis
 * @brief Student library for managing students, including Student type definition and student functions.
 * @version 0.1
 * @date 2022-04-12
 * 
 * 
 */

/**
 * @brief Student type stores a student with fields first_name, last_name, id, grades, num_grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< The student's first name */
  char last_name[50]; /**< The student's last name */
  char id[11]; /**< The student's id */
  double *grades; /**< The student's grades represented by an array */
  int num_grades; /**< The number of grades a student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
